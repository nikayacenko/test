package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

    // На SauceDemo после входа есть иконка корзины и заголовок "Products"
    @FindBy(className = "title")
    private WebElement pageTitleElement;

    @FindBy(className = "shopping_cart_link")
    private WebElement cartIcon;

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public boolean isUserLoggedIn() {
        try {
            return cartIcon.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public String getPageTitle() {
        return pageTitleElement.getText(); // Вернет "Products"
    }
}