package tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.HomePage;
import pages.LoginPage;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeEach
    public void setUp() {
        // Автоматически скачивает нужный драйвер для Chrome
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        
        // Открываем сайт
        driver.get("https://www.saucedemo.com/");
        
        // Явное ожидание до 10 секунд
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Test
    @DisplayName("Позитивный тест: Успешная авторизация")
    public void successLoginTest() {
        LoginPage loginPage = new LoginPage(driver);
        
        // На SauceDemo есть стандартный пользователь standard_user и пароль secret_sauce
        HomePage homePage = loginPage.login("standard_user", "secret_sauce");
        
        // Ждем, пока загрузится страница товаров (появится иконка корзины)
        wait.until(ExpectedConditions.visibilityOfElementLocated(org.openqa.selenium.By.className("shopping_cart_link")));
        
        assertTrue(homePage.isUserLoggedIn(), "Пользователь не авторизован (нет иконки корзины)");
        assertEquals("Products", homePage.getPageTitle(), "Заголовок страницы не 'Products'");
    }

    @Test
    @DisplayName("Негативный тест: Неверный пароль")
    public void wrongPasswordTest() {
        LoginPage loginPage = new LoginPage(driver);
        
        // Вводим верный логин, но неверный пароль
        loginPage.login("standard_user", "wrong_password");
        
        String errorText = loginPage.getErrorMessage();
        assertTrue(errorText.contains("Username and password do not match"), 
            "Текст ошибки не содержит фразу о несовпадении логина и пароля");
    }

    @Test
    @DisplayName("Негативный тест: Неверный логин")
    public void wrongLoginTest() {
        LoginPage loginPage = new LoginPage(driver);
        
        // Вводим неверный логин, но верный пароль
        loginPage.login("wrong_user", "secret_sauce");
        
        String errorText = loginPage.getErrorMessage();
        assertTrue(errorText.contains("Username and password do not match"), 
            "Текст ошибки не содержит фразу о несовпадении");
    }

    @Test
    @DisplayName("Негативный тест: Пустые поля")
    public void emptyFormTest() {
        LoginPage loginPage = new LoginPage(driver);
        
        loginPage.clearFields(); 
        loginPage.login("", ""); // Кликаем "Войти" с пустыми полями
        
        // Ждем появления сообщения об ошибке
        wait.until(ExpectedConditions.visibilityOfElementLocated(org.openqa.selenium.By.cssSelector("h3[data-test='error']")));
        String errorText = loginPage.getErrorMessage();
        
        assertTrue(errorText.contains("Username is required"), 
            "Нет сообщения о том, что логин обязателен");
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Закрываем браузер после каждого теста
        }
    }
}